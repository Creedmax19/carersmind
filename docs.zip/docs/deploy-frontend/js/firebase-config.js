// Firebase configuration (global)
(function() {
    window.firebaseConfig = {
        apiKey: "AIzaSyAkhBk-9_y6LIs3MjUjbyidk6f8BXS7_Hg",
        authDomain: "carersmind-cic.firebaseapp.com",
        projectId: "carersmind-cic",
        storageBucket: "carersmind-cic.firebasestorage.app",
        messagingSenderId: "728928980981",
        appId: "1:728928980981:web:adef960c40dd1bed065abc",
        measurementId: "G-FJ2X4R3T94"
    };
})();
